function Scaler(){

    this.scaleX = function(u){
        return 1;
    }

    this.scaleY = function(u){
        return 1;
    }

    this.scaleZ = function(u){
        return 1;
    }
}